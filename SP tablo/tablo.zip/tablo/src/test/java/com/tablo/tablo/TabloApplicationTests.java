package com.tablo.tablo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TabloApplicationTests {

	@Test
	void contextLoads() {
	}

}
